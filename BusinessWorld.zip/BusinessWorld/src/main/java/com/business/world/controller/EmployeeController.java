package com.business.world.controller;

import com.business.world.dao.DatabaseAccess;
import com.business.world.dto.Employee;
import com.business.world.entity.EmployeeEntity;
import com.business.world.util.JsonReader;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class EmployeeController {

@RequestMapping("/hello")
public String hello(){
    return "Welcome to Spring Boot Project";
}

    @PostMapping(value = "/creatEmployee")
    public void insertRecord(@RequestBody String json){
        System.out.println ("Inside insertRecord");
        EmployeeEntity emp = JsonReader.jsonToEmployee(json);
        System.out.println ("Employee created : " + emp.getFirstname());

        new DatabaseAccess().createEmployee(emp);

}
}
