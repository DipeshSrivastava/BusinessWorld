package com.business.world.dao;

import com.business.world.entity.EmployeeEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class DatabaseAccess implements IDatabaseAccess{

    private static final SessionFactory sessionFactory;

    static {
        try {
            Configuration config = new Configuration();
            sessionFactory = config.configure().buildSessionFactory();
        } catch (Throwable e) {
            System.err.println("Error in creating SessionFactory object."
                    + e.getMessage());
            throw new ExceptionInInitializerError(e);
          }
    }

    /*@Override
    public void createEmployee(EmployeeEntity emp) {
       final String sql = "insert into EMPLOYEE(EMPLOYEE_ID, FIRST_NAME , LAST_NAME, SALARY, ADDRESS_ID) values(:empId,:firstname,:lastname,:salary,:addressId)";
            KeyHol holder = new GeneratedKeyHolder();
            SqlParameterSource param = new MapSqlParameterSource()
                    .addValue("employeeId", emp.getEmployeeId())
                    .addValue("employeeName", emp.getEmployeeName())
                    .addValue("employeeEmail", emp.getEmployeeEmail())
                    .addValue("employeeAddress", emp.getEmployeeAddress());
            template.update(sql,param, holder);
        }
    }*/

    @Override
    public void createEmployee(EmployeeEntity emp) {
        //  HibernateUtil.getSessionFactory().openSession();
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        transaction = session.beginTransaction();
        session.saveOrUpdate(emp);
        transaction.commit();

    }

}
